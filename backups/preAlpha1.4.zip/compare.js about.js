warning: in the working copy of 'app.js', LF will be replaced by CRLF the next time Git touches it
warning: in the working copy of 'compare.js', LF will be replaced by CRLF the next time Git touches it
about.js
app.js
compare.js
