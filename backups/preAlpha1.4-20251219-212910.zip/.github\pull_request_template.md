### Changes
-

### Checks
- [ ] Minis: xaxis = Time, hover OFF, no Time-vs-Time, scrollZoom OFF.
- [ ] Mega: raw values in hover, scaling visual only.
- [ ] sessionStorage keys intact.
- [ ] Mobile tested (iPhone).
- [ ] Time slider works without crashes.

### Screenshots
